<template>
  <div>
    <Router-view></Router-view>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
