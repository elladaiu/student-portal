<template>
  <div class="tw-rounded-lg tw-bg-white tw-p-4 tw-w-full">
    <calendar-grid></calendar-grid>
  </div>
</template>

<script setup>
import CalendarGrid from '@/components/app/CalendarGrid.js'
</script>
